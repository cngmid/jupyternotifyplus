from IPython.testing.globalipapp import get_ipython

def test_magic_registration():
    ip = get_ipython()
    ip.extension_manager.load_extension("jupyternotifyplus")

    assert "notifyme" in ip.magics_manager.magics["line"]
