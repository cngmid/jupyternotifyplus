def test_import():
    import jupyternotifyplus
    assert hasattr(jupyternotifyplus, "load_ipython_extension")
